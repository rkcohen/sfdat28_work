##Ryan Cohen SFDAT28 Project 

Links

  * Paper: [https://docs.google.com/document/d/1gh9o-4-XCdm8DozmT_Ik4097dN4zNqULJqfyeYxXG_g/edit?usp=sharing](https://docs.google.com/document/d/1gh9o-4-XCdm8DozmT_Ik4097dN4zNqULJqfyeYxXG_g/edit?usp=sharing)
  * Presentation slides: [https://docs.google.com/presentation/d/1VyPXdHZcjQ3V5RBySMa-YcZ2wFyomwBHTN4yT99BFWs/edit?usp=sharing](https://docs.google.com/presentation/d/1VyPXdHZcjQ3V5RBySMa-YcZ2wFyomwBHTN4yT99BFWs/edit?usp=sharing)

Data sets and code are in this folder as well.  Reading the data sets in may not work in my current code due to a differing file locations than on my environment.